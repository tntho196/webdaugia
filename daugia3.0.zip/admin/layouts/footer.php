<?php  require_once __DIR__. "/../../autoload/autoload.php";  ?>
 </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->
        </div>
        <!-- /#wrapper -->
        <!-- jQuery -->
        <script src="<?php echo base_url()?>public/admin/js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo base_url()?>public/admin/js/bootstrap.min.js"></script>
    </body>
</html>