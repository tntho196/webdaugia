hello
<?php require_once __DIR__. "/../Layouts/header.php";  ?>
                    <!-- Page Heading  Nội dung -->
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">
                                Trang quản trị ADmin
                                <small>Subheading</small>
                            </h1>
                            <ol class="breadcrumb">
                                <li>
                                    <i class="fa fa-dashboard"></i>  <a href="index.html">Thêm Admin</a>
                                </li>
                                <li class="active">
                                    <i class="fa fa-file"></i> Hiển thị danh sách admin 
                                </li>
                            </ol>
                        </div>
                    </div>
                    <!-- /.row -->
<?php require_once __DIR__. "/../Layouts/footer.php";  ?>
               